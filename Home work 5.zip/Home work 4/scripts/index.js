"use strict";
// Вывод таблицы умножения для определенного числа в массив, 
// каждый элемент массива в виде: число * итератор = результат.
//  Для формирования строки используйте интерполяцию


// let number = 3;
// let i = 1;
// let arr = [];
// while (i <= 10) {
//  let result = number * i;
//  let row = `${number} * ${i} = ${result}`;
//  arr.push(row);
//  i++;
    
// }

// console.log(arr);

//Поиск первого положительного числа в массиве: 
// есть массив чисел и нужно найти первое число, которое является положительным.
// const arr = [-2,-3, 9, -5, -10, 20];
//  let i = 0;
//  let positiveNum;
//  while (i < arr.length) {
//   if (arr[i] > 0) {
//     positiveNum = arr[i];
//   break;
//   }
//     i++;
//  }
//  console.log(positiveNum);

//  Генерация случайного пароля: есть некая константа, 
// которая отвечает за длину пароля. 
// Сгенерируйте рандомный пароль до указанной длины, используя Math.random:
// const length = 9;
// const abc = 'abcdefghijklmnopqrstuvwxyz123456789';
// let boxPassw = '';
// let i = 0;
// while (i < length) {
//   const random = Math.floor(Math.random() * symbols.length) ;
//   boxPassw += symbols.charAt(random); 
//   i++;
// }
// console.log(boxPassw);

//  Объединение элементов массива в строку 
//  при помощи конкатенации: есть массив строк 
//  (например, список покупок) - необходимо вывести его в виде строки.
 
//for

// const array = ['meet', 'apple', 'water', 'milk'];
// let result = ' ';
// for (let i = 0; i < array.length; i++) {
//  result += array[i];
//   if (i !== array.length) {
//     result += ','
//   }
// }
// console.log(result);

//  Поиск наибольшего числа в массиве
 

// const numArr = [1, 32, 8, 5, 19, 0];
// let bigNum = numArr[0];
// for (let i = 0; i < numArr.length; i++) {
// if (numArr[i] > bigNum) {
//     bigNum = numArr[i];
//  }
// }
// console.log(bigNum);

//  Переворот строки: есть некая константа,содержащая строку. 
//   Необходимо вывести строку наоборот, используя цикл for
 
// const text = 'my brain dye in JS!';
// let boxStr = '';
// for (let i = str.length - 1; i >= 0; i--) {
//     boxStr += str[i];
// }
// console.log(boxStr);

// Подсчет количества гласных букв в строке: 
// есть строка и массив гласных в алфавите (можно выбрать английский). 
// Необходимо посчитать, сколько раз встречаются гласные в этой строке. Методы для решения этой задачи Вы найдете в файлике к уроку.

// const string = 'Hi i lov Js!';
// const vowels = ['a', 'e', 'i', 'o', 'u'];
// let index = 0;
// for ( let i = 0; i < string.length; i++) {
//     let lowCase = string.toLowerCase();
//     if (vowels.includes (lowCase[i])) {
//      index++;
//   }

// }
// console.log(index);

// Функции

//  Напишите функцию, которая принимает массив чисел и возвращает их сумму.
//  const arr1 = [7, 3, 5];
//  function Calc(boxCalcArrays) {
//     let itter = 0;
//     for (let i = 0; i < arr1.length; i++) {
//         itter += arr1[i];
//        }
      
//        console.log("Сумма чисел: " + itter); 
//     }
//  Calc(arr1)

// Напишите функцию findMax, которая принимает массив чисел и возвращает максимальное число из этого массива.
// const arr2 = [7, 3, 5];
// let bigFunNum = arr2[0];
// function findMax(num) {
//     for (let i = 0; i < arr2.length; i++) {
//          if (arr2[i] > bigFunNum) {
//             bigFunNum = arr2[i];
//           }
//           console.log("Макс число: " + bigFunNum);
//          }
// }
// findMax(arr2)


// Напишите функцию reverseArray, которая принимает массив и возвращает новый массив, в котором элементы идут в обратном порядке.

// let revArr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
// function reverseArray(reverseArr) {
//     const iArr = [];
//     for (let i = reverseArr.length - 1; i >= 0; i--) {
//         iArr.push(reverseArr[i]);
        
//     }
//       console.log(iArr);
//     return iArr;
      
// }

// reverseArray(revArr);

// Напишите функцию, которая принимает массив строк и возвращает новый массив, содержащий только строки, начинающиеся с заданной буквы.
// function filterStringsByLetter(arr, letter) {
//     const result = [];

//     for (let i = 0; i < arr.length; i++) {
//         const element = arr[i];
//         if (element.charAt(0) === letter) {
//             result.push(element);
//         }
//     }
//     return result
//   }
  
//   // Пример использования:
//   const strings = ['hello', 'i cry in java'];
//   const filteredStrings = filterStringsByLetter(strings, 'i');
//   console.log(filteredStrings); 


// Напишите функцию, которая принимает число и возвращает его факториал.

// function hateTerial(n) {
//     if (n === 0 || n === 1) {
//      return 1;   
//     } else {
//        return n * hateTerial(n - 1);
//     }
    
// }

// let num = 3;  
// let hateFun = hateTerial(num);
// console.log(hateFun);


// Напишите функцию, которая принимает число и возвращает "Fizz", 
// если число делится на 3, "Buzz", если число делится на 5, и "FizzBuzz",
//  если число делится и на 3, и на 5. В остальных случаях вернуть само число.

// function buzzFizz(params) {
//     if (params % 3 === 0 && params % 5 === 0) {
//         let fizzBuzz = 'FizzBuzz';
//         return fizzBuzz;
//     }
    
//      if (params % 3 === 0) {
//         let fizz = 'Fizz';
//         return fizz;  
//      }
    
//      if (params % 5 === 0) {
//          let buzz = 'Buzz';
//          return buzz;
//      } else {
//         return params;
//      }

    
    
// }

// let ada = buzzFizz(77);
// console.log(ada);

// Создайте функциональное выражение calculateCircleArea, 
// которое принимает объект circle с свойством radius и возвращает площадь круга.
// let circle = {
//     radius : 5
// }

// let calculateCircleArea = function fun(params) {
//     let f = params.radius ** 2 * Math.PI;
//     return f.toFixed(1); 
// }
// console.log(calculateCircleArea(circle));

// Создайте функциональное выражение getFullName, 
// которое принимает объект person с свойствами firstName и lastName и возвращает полное имя.
// const person = {
//     firstName : 'Sofa',
//     lastName : 'Abashidze'
//   }
// let getFullName = function (person) {
// return person.firstName + ' ' + person.lastName;
// }
// let fullName = getFullName(person);
// console.log(fullName);

// Создайте функциональное выражение calculateAverageGrade, 
// которое принимает объект student с массивом оценок grades и возвращает среднюю оценку студента 
// (попробуйте использовать reduce, описанный в файле предыдущего урока).

// let student = {
//     grades : [2, 3, 4, 5]
// }

// let calculateAverageGrade = student.grades.reduce((accum, iElement) =>  accum + iElement, 0);
// const fun = calculateAverageGrade / student.grades.length;
// console.log(fun);

// Создайте объект calculator с двумя свойствами operand1 и operand2, 
// и двумя методами: add и multiply. Метод add должен принимать два числа и возвращать их сумму,
//  а метод multiply должен принимать два числа и возвращать их произведение.
// const calculator = {
//     operand1 : 4,
//     operand2 : 2,
//     add : (opr, num2) => calculator.operand1 + calculator.operand2,
//     multiply : (num1, num2) => calculator.operand1 * calculator.operand2


// }
// console.log(calculator.add());
// console.log(calculator.multiply());